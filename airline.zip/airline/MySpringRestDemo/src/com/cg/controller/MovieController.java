package com.cg.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.bean.Movies;
import com.cg.service.IMovieService;
@RestController
public class MovieController {
	@Autowired
	IMovieService movieService;
	
	/**
	 * Method fetches all country details supporting HTTP GET method
	 * 
	 * @param  MODEL
	 * @return String - List Employee JSON
	 */
	@RequestMapping(value = "/movies",method = RequestMethod.GET,headers="Accept=application/json")
	public List<Movies> getAllMovies1(Model model) {
		
		
		return movieService.getAllMovies();
		
	}
	
	/**
	 * Method creates a spring form to create a country
	 * 
	 * @param id name population
	 * @return List-format JSON 
	 */
	
	/*@RequestMapping(value = "/countries/create/{id}/{name}/{popu}",
			headers="Accept=application/json", method = RequestMethod.POST)
	public List<Employee> createCountry(@PathVariable String id,@PathVariable String name,@PathVariable String popu) {
		Employee country=new Employee();
		country.setCountryId(id);
		country.setCountryName(name);
		country.setPopulation(popu);
		
		
		service.addCountry(country);
	
		return service.getAllCountries();
	}
	
	*//**
		 * Method creates a spring form to delete a country
		 * 
		 * @param id
		 * @return   List format Json
		 *//*
	*/
	@RequestMapping(value = "/movies/delete/{id}",
			headers="Accept=application/json",method = RequestMethod.DELETE)
	public List<Movies> deleteMovies1(@PathVariable("id") int id) {
		System.out.println(id);
		movieService.deleteMovie(id);
		return movieService.getAllMovies();
}
	@RequestMapping(value ="/movies/create/",consumes = MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json",method = RequestMethod.POST)
	public List<Movies> createMovies(@RequestBody Movies mov) {
		
		System.out.println(mov);
		movieService.addMovie(mov);
		return movieService.getAllMovies();
}
	@RequestMapping(value ="/movies/search/{cat}",headers="Accept=application/json",method = RequestMethod.GET)
	public List<Movies> searchMovies1(@PathVariable("cat") String cat) {
		System.out.println("In search");
		List<Movies> searchlist = movieService.searchMovie(cat);
		System.out.println(searchlist);
		return searchlist;
}
	@RequestMapping(value ="/movies/update/",consumes = MediaType.APPLICATION_JSON_VALUE,headers="Accept=application/json",method = RequestMethod.PUT)
	public List<Movies> updateMovies(@RequestBody Movies mov) {
		
		System.out.println("Update");
		System.out.println(mov);
		movieService.updateMovie(mov);
		return movieService.getAllMovies();
}

}
