package com.cg.staticdb;

import java.util.ArrayList;
import java.util.List;

import com.cg.bean.Movies;

public class MovieDB {

private static List<Movies> movieList=new ArrayList<Movies>();
	
	static{
		
		movieList.add(new Movies(1001,"Titanic",4,"Drama"));
		movieList.add(new Movies(1002,"Pacific Rim",5,"Fiction"));
		movieList.add(new Movies(1003,"Kungfu soccer",7,"Drama"));
		movieList.add(new Movies(1004,"Despicable Me 3",8,"Satire"));
		movieList.add(new Movies(1005,"Eragon",8,"Fiction"));
		movieList.add(new Movies(1006,"Ace Ventura",9,"Satire"));
	}

	public static List<Movies> getMovieList() {
		
		return movieList;
	}

	public static void setMovieList(List<Movies> movieList) {
		
		MovieDB.movieList = movieList;
	}
}
