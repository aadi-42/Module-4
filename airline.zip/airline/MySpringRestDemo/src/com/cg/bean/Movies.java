package com.cg.bean;

public class Movies {
private int moviesId;
private String moviesName;
private int moviesRating;
private String moviesGenre;

@Override
public String toString() {
	return "Movies [moviesId=" + moviesId + ", moviesName=" + moviesName + ", moviesRating=" + moviesRating
			+ ", moviesGenre=" + moviesGenre + "]";
}

public int getMoviesId() {
	return moviesId;
}

public void setMoviesId(int moviesId) {
	this.moviesId = moviesId;
}

public String getMoviesName() {
	return moviesName;
}

public void setMoviesName(String moviesName) {
	this.moviesName = moviesName;
}

public int getMoviesRating() {
	return moviesRating;
}

public void setMoviesRating(int moviesRating) {
	this.moviesRating = moviesRating;
}

public String getMoviesGenre() {
	return moviesGenre;
}

public void setMoviesGenre(String moviesGenre) {
	this.moviesGenre = moviesGenre;
}

public Movies() {
	super();
	// TODO Auto-generated constructor stub
}

public Movies(int moviesId, String moviesName, int moviesRating,
		String moviesGenre) {
	super();
	this.moviesId = moviesId;
	this.moviesName = moviesName;
	this.moviesRating = moviesRating;
	this.moviesGenre = moviesGenre;
}


}
