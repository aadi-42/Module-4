package com.cg.service;

import java.util.List;

import com.cg.bean.Movies;

public interface IMovieService {
	public List<Movies> getAllMovies();
	public void addMovie(Movies mov);
	public void deleteMovie(int id);
	public List<Movies> searchMovie(String cat);
	public void updateMovie(Movies mov);
}
