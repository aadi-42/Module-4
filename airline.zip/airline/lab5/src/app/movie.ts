export class Movies{
    moviesId:Number;
    moviesName:String;
    moviesRating:number;
    moviesGenre:string;
}