
import { Component } from '@angular/core';
import {Movies} from './movie';
import {MovieService} from './employee.service';
import {Router} from '@angular/router'
@Component({
 
  templateUrl:'./app.searchupdate.html',
  providers:[MovieService]
  
})
export class MovieSearchComponent {
    movieCategory:any[]=[
                              {dId:1,dName:"Drama"},                    
                              {dId:2,dName:"Fiction"}, 
                              {dId:3,dName:"Satire"}, 
                          ];
    constructor(private movservice:MovieService,private router:Router) {}
    statusmessage:string;
    msg:boolean=false;
    //employees:Employee[];
    model:any={};
    eid:any="";
    searchlist:Movies[];
searchData(option:any):void{
    this.movservice.searchMovieId(option).subscribe((data)=>this.searchlist=data,
            (error)=>{
                this.statusmessage="Problem with service check server"
                   // console.error(error);
            }    
            );
    /*console.log(this.b+'seat');
    alert(option)*/
    this.msg=true;
    //console.log(this.employees);
}
/*updatemovie():void{
    
    this.empservice.updateMovie(this.model).subscribe((data)=>this.b=data,
            (error)=>{
                this.statusmessage="Problem with service check server"
                   // console.error(error);
            }    
            );
  //Navigate from EmployeeSearchComponent to EmployeeList
    this.router.navigate(['/getdata',{term:this.b}]);
}
*/
}