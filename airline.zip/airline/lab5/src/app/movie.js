"use strict";
var Movies = (function () {
    function Movies() {
    }
    return Movies;
}());
exports.Movies = Movies;
