export interface IFlight {
    id: number;
    fname: string;
    departureTime: string;
    arrivalTime:string;
    status:string;
    cost: number;
}