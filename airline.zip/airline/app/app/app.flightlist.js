"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var flight_service_1 = require("./flight.service");
var FlightList = (function () {
    function FlightList(flightservice) {
        this.flightservice = flightservice;
        this.path = ['flight'];
        this.order = 1; // 1 asc, -1 desc;
        this.search = '';
        this.index = 0;
        this.status = false;
        this.addBoolean = false;
        this.flight = {};
    }
    FlightList.prototype.changeIndexToOne = function () {
        this.index = 1;
        console.log("index changed to: " + this.index);
    };
    FlightList.prototype.changeIndexToTwo = function () {
        this.index = 2;
        console.log("index changed to: " + this.index);
    };
    FlightList.prototype.changeIndexToThree = function () {
        this.index = 3;
        console.log("index changed to: " + this.index);
    };
    FlightList.prototype.changeIndexToFour = function () {
        this.index = 4;
        console.log("index changed to: " + this.index);
    };
    FlightList.prototype.changeIndexToFive = function () {
        this.index = 5;
        console.log("index changed to: " + this.index);
    };
    FlightList.prototype.changeIndexToSix = function () {
        this.index = 6;
        console.log("index changed to: " + this.index);
    };
    FlightList.prototype.changeIndexToSeven = function () {
        this.index = 7;
        console.log("index changed to: " + this.index);
    };
    FlightList.prototype.ngOnInit = function () {
        var _this = this;
        console.log("Hi");
        this.flightservice.getAllFlight().subscribe(function (flightData) { return _this.flights = flightData; });
    };
    FlightList.prototype.sortTable = function (prop) {
        this.path = prop.split('.');
        this.order = this.order * 1; // change order
        return false; // do not reload
    };
    FlightList.prototype.delete = function (flight1) {
        console.log(flight1);
        var index1 = this.flights.indexOf(flight1, 0);
        console.log(index1);
        this.flights.splice(index1, 1);
    };
    FlightList.prototype.update = function (flight2) {
        this.status = true;
        var index1 = this.flights.indexOf(flight2, 0);
        console.log(index1);
        this.fId = this.flights[index1].id;
        this.fName = this.flights[index1].name;
        this.fFrom = this.flights[index1].from;
        this.fTo = this.flights[index1].to;
        this.fTime = this.flights[index1].depTime;
        this.fDate = this.flights[index1].depDate;
        this.fPrice = this.flights[index1].price;
        this.count = index1;
    };
    FlightList.prototype.updateFlight = function () {
        this.status = false;
        this.flights[this.count].id = this.fId;
        this.flights[this.count].name = this.fName;
        this.flights[this.count].from = this.fFrom;
        this.flights[this.count].to = this.fTo;
        this.flights[this.count].depTime = this.fTime;
        this.flights[this.count].depDate = this.fDate;
        this.flights[this.count].price = this.fPrice;
    };
    FlightList.prototype.addFlight = function () {
        this.fId = null;
        this.fName = null;
        this.fFrom = null;
        this.fTo = null;
        this.fTime = null;
        this.fDate = null;
        this.fPrice = null;
        this.addBoolean = true;
    };
    FlightList.prototype.add = function () {
        var flightData = this.createFlight();
        console.log(flightData);
        /* this.flights.push(flightData);*/
        this.flights.push(Object.assign({}, flightData));
        this.addBoolean = false;
    };
    FlightList.prototype.createFlight = function () {
        this.flight.id = this.fId;
        this.flight.name = this.fName;
        this.flight.from = this.fFrom;
        this.flight.to = this.fTo;
        this.flight.depTime = this.fTime;
        this.flight.depDate = this.fDate;
        this.flight.price = this.fPrice;
        return this.flight;
    };
    return FlightList;
}());
FlightList = __decorate([
    core_1.Component({
        selector: '<my-component></my-component>',
        templateUrl: './app.flightcomponent.html',
        providers: [flight_service_1.FlightService]
    }),
    __metadata("design:paramtypes", [flight_service_1.FlightService])
], FlightList);
exports.FlightList = FlightList;
