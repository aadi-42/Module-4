export interface IFlight{
    id:number,
    name:string,
    from:string,
    to:string,
    depTime:string,
    depDate:string,
    price:number;

}