import { Injectable }      from '@angular/core';
import {IFlight} from './flight';
import {Http,Response} from '@angular/http';
import { Observable } from 'rxjs/Observable';
import "rxjs/add/operator/map"
@Injectable()
export class FlightService{
    constructor(private http:Http) {
	
}
    
    getAllFlight():Observable<IFlight[]> 
{ /*return  this.http.get("http://localhost:9090/SpringWithAngular/rest/employee").*/
        return  this.http.get("app/flight.json").
        map((response:Response)=><IFlight[]>response.json());
    }
}