import {Component,OnInit} from '@angular/core';
import {IFlight} from './flight';
import {FlightService} from './flight.service'
@Component({
    selector:'<my-component></my-component>',
    templateUrl:'./app.flightcomponent.html',
    providers:[FlightService]
})
export class FlightList implements  OnInit{
    
    flights:IFlight[];
path: string[] = ['flight'];
order: number = 1; // 1 asc, -1 desc;
search: string = '';
index: number=0;
status:boolean=false;
count: number;

fId:number;
fName:string;
fFrom:string;
fTo:string;
fPrice:number;
fTime:string;
fDate:string;

addBoolean:boolean=false;
flight:any={};

changeIndexToOne(): void {
    this.index = 1;
    console.log("index changed to: " + this.index);
}
changeIndexToTwo(): void {
    this.index = 2;
    console.log("index changed to: " + this.index);
}
changeIndexToThree(): void {
    this.index = 3;
    console.log("index changed to: " + this.index);
}
changeIndexToFour(): void {
    this.index = 4;
    console.log("index changed to: " + this.index);
}
changeIndexToFive(): void {
    this.index = 5;
    console.log("index changed to: " + this.index);
}
changeIndexToSix(): void {
    this.index = 6;
    console.log("index changed to: " + this.index);
}
changeIndexToSeven(): void {
    this.index = 7;
    console.log("index changed to: " + this.index);
}

constructor(private flightservice:FlightService) {
   
}
ngOnInit(): void {
    console.log("Hi");
    this.flightservice.getAllFlight().subscribe((flightData)=>this.flights=flightData);
}
sortTable( prop: string ) {
    this.path = prop.split( '.' )
    this.order = this.order * 1; // change order
    return false; // do not reload
} 
 delete(index1:number):void{
     console.log(index1);
     this.flights.splice(index1,1);
 }    
 update(index1: number): void{
     console.log(index1);
     this.status=true;
     this.fId = this.flights[index1].id;
     this.fName = this.flights[index1].name;
     this.fFrom = this.flights[index1].from;
     this.fTo = this.flights[index1].to;
     this.fTime = this.flights[index1].depTime;
     this.fDate = this.flights[index1].depDate;
     this.fPrice = this.flights[index1].price;
     this.count = index1;
     
 }
 
 updateFlight(): void{
     this.status = false;
     this.flights[this.count].id = this.fId;
     this.flights[this.count].name = this.fName;
     this.flights[this.count].from = this.fFrom;
     this.flights[this.count].to = this.fTo;
     this.flights[this.count].depTime = this.fTime;
     this.flights[this.count].depDate = this.fDate;
     this.flights[this.count].price = this.fPrice;
 } 
 
 addFlight():void{
     this.fId = null;
     this.fName = null;
     this.fFrom = null;
     this.fTo = null;
     this.fTime = null;
     this.fDate = null;
     this.fPrice = null;
     this.addBoolean=true;
 }
 
 add():void{
     let flightData=this.createFlight();
     console.log(flightData);
     this.flights.push(flightData);
     this.addBoolean=false;
     
 }
 createFlight():IFlight{
         this.flight.id=this.fId;
         this.flight.name=this.fName;         
         this.flight.from=this.fFrom;
         this.flight.to=this.fTo;
         this.flight.depTime=this.fTime;
         this.flight.depDate=this.fDate;
         this.flight.price=this.fPrice;
         return this.flight;
          
      
 }
}