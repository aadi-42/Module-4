import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { AppComponent }  from './app.component';
import { FlightList }  from './app.flightlist';
import {HttpModule} from '@angular/http';
import { SortingFlightsPipe }  from './sort.pipe';
import { SearchPipe }  from './filter';

@NgModule({
  imports:      [ BrowserModule,FormsModule,HttpModule ],
  declarations: [ AppComponent,FlightList,SortingFlightsPipe,SearchPipe],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
