package com.capg.bean;

public class Flight {
	
	private int flightNo;
	private String name;
	private String flightName;
	private String source;
	private String destination;
	private int price;
	
	




	public Flight() {
		super();
		
	}
	
	
	
	
	public Flight(int flightNo, String name, String flightName, String source,
			String destination, int price) {
		super();
		this.flightNo = flightNo;
		this.name = name;
		this.flightName = flightName;
		this.source = source;
		this.destination = destination;
		this.price = price;
	}




	@Override
	public String toString() {
		return "Flight [flightNo=" + flightNo + ", name=" + name
				+ ", flightName=" + flightName + ", source=" + source
				+ ", destination=" + destination + "]";
	}




	public int getFlightNo() {
		return flightNo;
	}
	public void setFlightNo(int flightNo) {
		this.flightNo = flightNo;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getFlightName() {
		return flightName;
	}
	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getDestination() {
		return destination;
	}
	public void setDestination(String destination) {
		this.destination = destination;
	}
	
	public int getPrice() {
		return price;
	}




	public void setPrice(int price) {
		this.price = price;
	}


}
