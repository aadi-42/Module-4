package com.capg.DBUtil;

import java.util.ArrayList;
import java.util.List;

import com.capg.bean.Flight;



public class FlightDB {
	
	static List<Flight> flightDetails = null;
	
	static {
		if(flightDetails==null) {
			
			flightDetails = new ArrayList<Flight>();
			
			flightDetails.add(new Flight(101,"Aniruddh","Jet Airways","Bangalore","Mumbai", 100));
			flightDetails.add(new Flight(102,"Karan","Air India","Hydrabad","Mumbai", 150));
			flightDetails.add(new Flight(103,"Aditya","Indogo","Pune","Chennai", 140));
			flightDetails.add(new Flight(104,"Sumit","Go Airways","Bangalore","Delhi", 200));
			flightDetails.add(new Flight(105,"Tejas","Vistara","Delhi","Kerla", 330));
			
		}
	}

	public static List<Flight> getFlightDetails() {
		
		return flightDetails;
	}

	public static int addFlightDetails(Flight flight) {
		
		
		
		boolean status = flightDetails.add(flight);
		
		if(status==true)
		{
			return 1;
		}
		
		return 0;
	}

	public static List<Flight> deleteFlightDetails(int id) {
		
		Flight flight = new Flight();
		
		for (Flight detail : flightDetails) {
			
			if(detail.getFlightNo()==id)
			{
				flight = detail;
				break;
			}
			
		}
		
		
		flightDetails.remove(flight);
		
		return flightDetails;
	}

	public static List<Flight> updateFlightDetails(Flight flight) {
		
		for (Flight fDetail : flightDetails) {
			
			if(fDetail.getFlightNo()==flight.getFlightNo())
			{
				fDetail.setName(flight.getName());
				fDetail.setFlightName(flight.getFlightName());
				fDetail.setSource(flight.getSource());
				fDetail.setDestination(flight.getDestination());
				fDetail.setPrice(flight.getPrice());
			}
			
		}
		
		
		return flightDetails;
	}
	
	
	
	
	

}
