export class Flight {
    
     flightNo : number;
     name : String;
     flightName : String;
     source : String;
     destination : String;
     price : number;
     date : Date;
    
}