"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var flight_service_1 = require("./flight.service");
var filter_1 = require("./filter");
var Display = (function () {
    function Display(flightService, pipe) {
        this.flightService = flightService;
        this.pipe = pipe;
        ///////
        ///////
        //////
        ////
        this.column = "name";
        this.temp = 1;
        this.status = false;
        this.path = ['flightNo'];
        this.order = 1; // 1 asc, -1 desc;
    }
    Display.prototype.ngOnInit = function () {
        var _this = this;
        this.flightService.getFlightDetails().subscribe(function (flightData) {
            _this.flight = flightData;
            _this.tmp2 = flightData;
        }, function (error) {
            _this.statusmessage = "Problem with Server";
        });
    };
    Display.prototype.sortTable = function (prop) {
        this.path = prop.split('.');
        this.order = this.order * (-1); // change order
        return false; // do not reload
    };
    Display.prototype.action = function () {
        console.log(this.tmp2);
        this.tmp = this.pipe.transform(this.tmp2, this.flightNo, "flightNo");
        this.tmp = this.pipe.transform(this.tmp, this.name, "name");
        this.tmp = this.pipe.transform(this.tmp, this.flightName, "flightName");
        this.tmp = this.pipe.transform(this.tmp, this.source, "source");
        this.tmp = this.pipe.transform(this.tmp, this.destination, "destination");
        this.tmp = this.pipe.transform(this.tmp, this.price, "price");
        this.flight = this.pipe.transform(this.tmp, this.date, "date");
    };
    Display.prototype.delete = function (id) {
        var _this = this;
        this.flightService.deleteFlightDetails(id).subscribe(function (details) { return _this.flight = details; }, function (error) {
            _this.statusmessage = "Problem with Server";
        });
    };
    Display.prototype.change = function (id) {
        this.status = true;
        this.uid = id;
    };
    Display.prototype.update = function () {
        var _this = this;
        this.fDetails = {
            flightNo: this.uid,
            name: this.uName,
            flightName: this.uFlightName,
            source: this.uSource,
            destination: this.uDestination,
            price: this.upPrice,
            date: this.udate
        };
        this.flightService.updateFlightDetails(this.fDetails).subscribe(function (details) { return _this.flight = details; }, function (error) {
            _this.statusmessage = "Problem with Server";
        });
        this.status = false;
        this.uid = null;
        this.uName = "";
        this.uFlightName = "";
        this.uSource = "";
        this.uDestination = "";
        this.upPrice = null;
        this.udate = null;
    };
    return Display;
}());
Display = __decorate([
    core_1.Component({
        selector: '<app-display><app-display>',
        templateUrl: './app.display.html',
        providers: [flight_service_1.FlightService, filter_1.SearchPipe]
    }),
    __metadata("design:paramtypes", [flight_service_1.FlightService, filter_1.SearchPipe])
], Display);
exports.Display = Display;
