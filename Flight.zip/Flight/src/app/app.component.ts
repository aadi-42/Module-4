import { Component } from '@angular/core';
import { Router } from '@angular/router'; 

@Component({
  selector: 'my-app',
  templateUrl:'./app.option.html'
  
})
export class AppComponent { 
    name = 'Welcome Angular 2'; 







}
