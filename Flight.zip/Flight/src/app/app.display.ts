import { Component, OnInit } from '@angular/core';
import { FlightService } from "./flight.service";
import { Flight } from "./app.flight";
import { SearchPipe } from "./filter";
import { Form } from "@angular/forms/forms";


@Component( {
    selector: '<app-display><app-display>',
    templateUrl: './app.display.html',
    providers: [FlightService, SearchPipe]

} )

export class Display implements OnInit {

    statusmessage: string;
    flight: Flight[];
    fDetails : Flight;
    tmp : Flight[];

///////
///////
//////
////

    column: string = "name";
    find: any;

   
    flightNo: number;
    name: String;
    flightName: String;
    source: String;
    destination: String;
    price: number;
    date : Date;

    temp:number=1;
    status : boolean = false; 

    uid : number;
    uName : string;
    uFlightName : string;
    uSource : string;
    uDestination : string;
    upPrice : number;
    udate : Date;
    tmp2 : Flight[];

    constructor( private flightService: FlightService, private pipe : SearchPipe ) {
    }

    ngOnInit(): void {



        this.flightService.getFlightDetails().subscribe(( flightData ) => {
            this.flight = flightData;
            this.tmp2 = flightData    
        },
            ( error ) => {
                this.statusmessage = "Problem with Server"
            } );

        

    }

    flights: Flight[];
    path: string[] = ['flightNo'];
    order: number = 1; // 1 asc, -1 desc;

    sortTable( prop: string ) {
        this.path = prop.split( '.' )
        this.order = this.order * ( -1 ); // change order
        return false; // do not reload
    }


   
    
    action()
    {
        console.log(this.tmp2);
       
        this.tmp = this.pipe.transform(this.tmp2,this.flightNo,"flightNo");
        this.tmp = this.pipe.transform(this.tmp,this.name,"name");
        this.tmp = this.pipe.transform(this.tmp,this.flightName,"flightName");
        this.tmp = this.pipe.transform(this.tmp,this.source,"source");
        this.tmp = this.pipe.transform(this.tmp,this.destination,"destination");
        this.tmp = this.pipe.transform(this.tmp,this.price,"price");
        this.flight = this.pipe.transform(this.tmp,this.date,"date");
        
    }
    
    
    
    delete(id:number)
    {
        
        this.flightService.deleteFlightDetails(id).subscribe((details)=>this.flight=details,
                (error)=>{
                    this.statusmessage = "Problem with Server"
                });
        
    }
    
    change(id:number)
    {
        this.status = true;
        this.uid = id;
    }
    
    update()
    {
      this.fDetails = {
              
              flightNo : this.uid,
              name : this.uName,
              flightName : this.uFlightName,
              source : this.uSource,
              destination : this.uDestination,
              price : this.upPrice,
              date : this.udate
     
      };
      
      
      this.flightService.updateFlightDetails(this.fDetails).subscribe((details)=>this.flight=details,
         (error)=>{
             this.statusmessage = "Problem with Server"
    });
      
       this.status = false;
      
       this.uid = null;
       this.uName = "";
       this.uFlightName = "";
       this.uSource = "";
       this.uDestination="";
       this.upPrice = null;
       this.udate = null;
       
    }

    
     

}